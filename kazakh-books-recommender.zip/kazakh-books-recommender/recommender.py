"""Контентный рекомендатель казахских книг: TF-IDF + косинусная схожесть.

Идея: описание каждой книги превращается в TF-IDF вектор. Профиль читателя =
среднее векторов книг, которые ему понравились. Рекомендуем непрочитанные
книги, чьи векторы ближе всего к профилю.

Казахский язык агглютинативный (много окончаний), поэтому по умолчанию
используются символьные n-граммы (char_wb, 2-5): «батырдың», «батыр»,
«батырлар» получают общие признаки без стеммера.
"""
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

LIKE_THRESHOLD = 4  # рейтинг >= 4 считаем «понравилось»


def make_vectorizer(kind="char"):
    if kind == "char":
        return TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), lowercase=True, sublinear_tf=True)
    if kind == "word":
        return TfidfVectorizer(analyzer="word", lowercase=True, sublinear_tf=True)
    raise ValueError("kind must be 'char' or 'word'")


class BookRecommender:
    def __init__(self, books: pd.DataFrame, kind: str = "char", use_genre: bool = True):
        self.books = books.reset_index(drop=True)
        self.vec = make_vectorizer(kind)
        # обучаем словарь только на текстах каталога, оценки читателей не используются
        parts = self.books.title + ". " + self.books.description
        if use_genre:  # жанр из метаданных каталога добавляется в текст как слово
            parts = parts + " " + self.books.genre.str.replace("_", " ")
        text = parts.tolist()
        self.X = self.vec.fit_transform(text)
        self.id_to_idx = {b: i for i, b in enumerate(self.books.book_id)}

    def scores(self, liked_ids):
        idx = [self.id_to_idx[b] for b in liked_ids if b in self.id_to_idx]
        if not idx:
            raise ValueError("Нужна хотя бы одна понравившаяся книга")
        profile = np.asarray(self.X[idx].mean(axis=0))
        return cosine_similarity(profile, self.X).ravel()

    def recommend(self, liked_ids, k=5, exclude_ids=()):
        s = self.scores(liked_ids)
        banned = {self.id_to_idx[b] for b in set(liked_ids) | set(exclude_ids) if b in self.id_to_idx}
        order = [i for i in np.argsort(-s) if i not in banned][:k]
        out = self.books.iloc[order].copy()
        out["similarity"] = s[order]
        return out

    def similar_terms(self, liked_ids, book_id, n=5):
        """Какие n-граммы/слова объясняют рекомендацию (для пояснения пользователю)."""
        idx = [self.id_to_idx[b] for b in liked_ids]
        prof = np.asarray(self.X[idx].mean(axis=0)).ravel()
        vec = self.X[self.id_to_idx[book_id]].toarray().ravel()
        contrib = prof * vec
        names = np.array(self.vec.get_feature_names_out())
        top = np.argsort(-contrib)[: n * 4]
        terms = [t.strip() for t in names[top] if len(t.strip()) >= 4]
        return terms[:n]
