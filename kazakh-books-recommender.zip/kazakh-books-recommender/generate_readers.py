"""Генерация СИНТЕТИЧЕСКИХ читательских профилей.

Все читатели ВЫМЫШЛЕННЫЕ. Реальных людей и персональных данных здесь нет.
Результат: data/synthetic_ratings.csv (reader_id, book_id, rating 1-5).

Как генерируется:
  * у каждого читателя 1-2 «любимых» жанра (скрыты, в файл не пишутся);
  * читатель оценивает 12 случайных книг;
  * книга любимого жанра получает 4-5, остальные 1-3;
  * в 15 % случаев оценка «ломается» (шум: вкусы не идеальны).
Запуск: python generate_readers.py
"""
import numpy as np
import pandas as pd

SEED = 42
N_READERS = 60
N_RATED = 12
NOISE = 0.15


def main():
    rng = np.random.default_rng(SEED)
    books = pd.read_csv("data/books.csv")
    genres = sorted(books.genre.unique())
    rows = []
    for rid in range(1, N_READERS + 1):
        n_fav = rng.choice([1, 2], p=[0.6, 0.4])
        fav = set(rng.choice(genres, size=n_fav, replace=False))
        picked = rng.choice(books.book_id.values, size=N_RATED, replace=False)
        for bid in picked:
            g = books.loc[books.book_id == bid, "genre"].iloc[0]
            liked = g in fav
            if rng.random() < NOISE:
                liked = not liked
            rating = int(rng.integers(4, 6)) if liked else int(rng.integers(1, 4))
            rows.append((rid, int(bid), rating))
    out = pd.DataFrame(rows, columns=["reader_id", "book_id", "rating"])
    out.to_csv("data/synthetic_ratings.csv", index=False)
    print(f"Сохранено {len(out)} оценок от {out.reader_id.nunique()} синтетических читателей")


if __name__ == "__main__":
    main()
