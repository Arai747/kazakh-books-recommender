"""Проверка качества рекомендателя. Запуск: python evaluate.py

Схема (leave-one-out по каждому понравившемуся элементу):
  1. Для читателя берём книги с рейтингом >= 4 («понравилось»).
  2. Одну из них прячем (TEST). Профиль строим по остальным (TRAIN).
  3. Кандидаты: все книги, кроме тех, что читатель уже оценил, + спрятанная.
  4. Hit@5 = спрятанная книга попала в топ-5.
Сравниваем: char TF-IDF (основной), word TF-IDF (альтернатива), популярность и случайный выбор.
TF-IDF словарь учится только на описаниях каталога, оценки читателей в нём не участвуют.
"""
import os

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score

from recommender import LIKE_THRESHOLD, BookRecommender

K = 5
SEED = 0
os.makedirs("results", exist_ok=True)

books = pd.read_csv("data/books.csv")
ratings = pd.read_csv("data/synthetic_ratings.csv")
rng = np.random.default_rng(SEED)

models = {"char": BookRecommender(books, "char"), "word": BookRecommender(books, "word"),
          "char_no_genre": BookRecommender(books, "char", use_genre=False),
          "word_no_genre": BookRecommender(books, "word", use_genre=False)}


def popularity(exclude_reader):
    liked = ratings[(ratings.rating >= LIKE_THRESHOLD) & (ratings.reader_id != exclude_reader)]
    return liked.book_id.value_counts()


def run():
    hits = {"char": [], "word": [], "char_no_genre": [], "word_no_genre": [], "popularity": [], "random": []}
    log = []  # (reader, test_book, hit_char, top5)
    for rid, g in ratings.groupby("reader_id"):
        liked = g[g.rating >= LIKE_THRESHOLD].book_id.tolist()
        if len(liked) < 3:
            continue
        rated = set(g.book_id)
        for test in liked:
            train = [b for b in liked if b != test]
            seen = rated - {test}
            cand = [b for b in books.book_id if b not in seen and b not in train]
            for name in ("char", "word", "char_no_genre", "word_no_genre"):
                top = models[name].recommend(train, k=K, exclude_ids=seen)
                hits[name].append(int(test in top.book_id.tolist()))
                if name == "char":
                    log.append((rid, test, train, top.book_id.tolist()))
            pop = popularity(rid)
            pop_rank = sorted(cand, key=lambda b: -pop.get(b, 0))[:K]
            hits["popularity"].append(int(test in pop_rank))
            hits["random"].append(int(test in rng.choice(cand, size=K, replace=False).tolist()))
    return hits, log


hits, log = run()
n = len(hits["char"])
lines = [f"# Результаты (синтетические читатели)\n", f"Тестов (leave-one-out): {n}, K={K}\n",
         "| Метод | Hit@5 |", "|---|---|"]
for name in ("char", "word", "char_no_genre", "word_no_genre", "popularity", "random"):
    lines.append(f"| {name} | {np.mean(hits[name]):.3f} |")

# кластеризация книг
km_rows = []
for name in ("char", "word", "char_no_genre"):
    X = models[name].X
    km = KMeans(n_clusters=5, n_init=10, random_state=0).fit(X)
    sil = silhouette_score(X, km.labels_)
    ari = adjusted_rand_score(books.genre, km.labels_)
    km_rows.append((name, sil, ari))
    if name == "char":
        books["cluster"] = km.labels_
lines += ["", "## Кластеризация книг (KMeans, k=5)", "| TF-IDF | silhouette | ARI vs жанр |", "|---|---|---|"]
for name, s, a in km_rows:
    lines.append(f"| {name} | {s:.3f} | {a:.3f} |")
lines += ["", "### Состав кластеров (char)"]
for c, g in books.groupby("cluster"):
    lines.append(f"- кластер {c}: " + "; ".join(g.title) + f" (жанры: { {k: int(v) for k, v in g.genre.value_counts().items()} })")

# три примера проверки + разбор ошибки
by_id = books.set_index("book_id")
ex = ["", "## Три примера проверки"]
shown = 0
for rid, test, train, top in log:
    if shown >= 3:
        break
    if test in top and len(train) >= 3:
        ex.append(f"- Читатель #{rid} любит: " + ", ".join(by_id.loc[train, "title"]) +
                  f". Скрытая книга «{by_id.loc[test, 'title']}» → в топ-5: " +
                  ", ".join(by_id.loc[top, "title"]) + " ✔")
        shown += 1
miss = [(r, t, tr, tp) for r, t, tr, tp in log if t not in tp]
ex += ["", "## Пример ошибки"]
if miss:
    r, t, tr, tp = miss[0]
    ex.append(f"- Читатель #{r}: скрыта «{by_id.loc[t, 'title']}» (жанр {by_id.loc[t, 'genre']}), "
              f"по любимым ({', '.join(by_id.loc[tr, 'title'])}) предложено: " +
              ", ".join(f"{by_id.loc[b, 'title']} [{by_id.loc[b, 'genre']}]" for b in tp))
ex.append(f"- Всего промахов: {len(miss)} из {len(log)}")
lines += ex

with open("results/results.md", "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
print("\n".join(lines))
