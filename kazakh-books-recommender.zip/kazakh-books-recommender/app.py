"""Сайт-прототип. Запуск: streamlit run app.py"""
import pandas as pd
import streamlit as st

from recommender import BookRecommender

st.set_page_config(page_title="Қазақ кітаптары", page_icon="📚")


@st.cache_data
def load_books():
    return pd.read_csv("data/books.csv")


books = load_books()
rec = BookRecommender(books, "char")

st.title("📚 Қазақ кітаптарын ұсыну / Рекомендации казахских книг")
st.caption("Демо: описания и читатели синтетические, см. README.")

titles = dict(zip(books.title, books.book_id))
liked_titles = st.multiselect("Сізге қандай кітаптар ұнады? / Какие книги вам понравились?", list(titles))
k = st.slider("Қанша ұсыныс? / Сколько рекомендаций", 1, 10, 5)

if liked_titles:
    liked_ids = [titles[t] for t in liked_titles]
    out = rec.recommend(liked_ids, k=k)
    for _, r in out.iterrows():
        terms = ", ".join(rec.similar_terms(liked_ids, r.book_id))
        with st.container(border=True):
            st.subheader(r.title)
            st.write(f"**{r.author}** · {r.genre} · сходство: {r.similarity:.2f}")
            st.write(r.description)
            st.caption(f"Общие признаки: {terms}")
else:
    st.info("Кемінде бір кітапты таңдаңыз / Выберите хотя бы одну книгу")
