"""Ұсыныс жүйесінің сапасын тексеру. Іске қосу: python evaluate.py

Схема (ұнаған әр элемент бойынша leave-one-out):
  1. Оқырманның бағасы >= 4 кітаптарын («ұнады») аламыз.
  2. Біреуін жасырамыз (TEST). Профильді қалғандарынан құрамыз (TRAIN).
  3. Үміткерлер: оқырман әлі бағаламаған барлық кітап + жасырылған кітап.
  4. Hit@5 = жасырылған кітап топ-5-ке түсті ме.
Салыстырамыз: char TF-IDF (негізгі), word TF-IDF (балама), танымалдық және кездейсоқ таңдау.
TF-IDF сөздігі тек каталог сипаттамаларына үйретіледі, оқырман бағалары оған қатыспайды.
"""
import os

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score

from recommender import LIKE_THRESHOLD, BookRecommender

K = 5
SEED = 0
os.makedirs("results", exist_ok=True)

books = pd.read_csv("data/books.csv")
ratings = pd.read_csv("data/synthetic_ratings.csv")
rng = np.random.default_rng(SEED)

models = {"char": BookRecommender(books, "char"), "word": BookRecommender(books, "word"),
          "char_no_genre": BookRecommender(books, "char", use_genre=False),
          "word_no_genre": BookRecommender(books, "word", use_genre=False)}


def popularity(exclude_reader):
    liked = ratings[(ratings.rating >= LIKE_THRESHOLD) & (ratings.reader_id != exclude_reader)]
    return liked.book_id.value_counts()


def run():
    hits = {"char": [], "word": [], "char_no_genre": [], "word_no_genre": [], "popularity": [], "random": []}
    log = []  # (оқырман, тест кітабы, train, топ-5)
    for rid, g in ratings.groupby("reader_id"):
        liked = g[g.rating >= LIKE_THRESHOLD].book_id.tolist()
        if len(liked) < 3:
            continue
        rated = set(g.book_id)
        for test in liked:
            train = [b for b in liked if b != test]
            seen = rated - {test}
            cand = [b for b in books.book_id if b not in seen and b not in train]
            for name in ("char", "word", "char_no_genre", "word_no_genre"):
                top = models[name].recommend(train, k=K, exclude_ids=seen)
                hits[name].append(int(test in top.book_id.tolist()))
                if name == "char":
                    log.append((rid, test, train, top.book_id.tolist()))
            pop = popularity(rid)
            pop_rank = sorted(cand, key=lambda b: -pop.get(b, 0))[:K]
            hits["popularity"].append(int(test in pop_rank))
            hits["random"].append(int(test in rng.choice(cand, size=K, replace=False).tolist()))
    return hits, log


hits, log = run()
n = len(hits["char"])
lines = ["# Нәтижелер (синтетикалық оқырмандар)\n", f"Тесттер саны (leave-one-out): {n}, K={K}\n",
         "| Әдіс | Hit@5 |", "|---|---|"]
for name in ("char", "word", "char_no_genre", "word_no_genre", "popularity", "random"):
    lines.append(f"| {name} | {np.mean(hits[name]):.3f} |")

# --- негізгі метрика: Precision@10 (скрытая «ақиқат» синтетикалық оқырмандарда) ---
truth = pd.read_csv("data/synthetic_readers_truth.csv").set_index("reader_id").favorite_groups.str.split(";")
group_of = books.set_index("book_id").genre_group
KP = 10
prec = {"char": [], "word": [], "char_no_genre": [], "word_no_genre": [], "popularity": [], "random": []}
for rid, g in ratings.groupby("reader_id"):
    liked = g[g.rating >= LIKE_THRESHOLD].book_id.tolist()
    if len(liked) < 3:
        continue
    seen = set(g.book_id)
    cand = [b for b in books.book_id if b not in seen]
    fav = set(truth[rid])
    ok = lambda ids: np.mean([group_of[b] in fav for b in ids])
    for name in ("char", "word", "char_no_genre", "word_no_genre"):
        prec[name].append(ok(models[name].recommend(liked, k=KP, exclude_ids=seen).book_id.tolist()))
    pop = popularity(rid)
    prec["popularity"].append(ok(sorted(cand, key=lambda b: -pop.get(b, 0))[:KP]))
    prec["random"].append(ok(rng.choice(cand, size=KP, replace=False).tolist()))
lines += ["", f"## Негізгі метрика: Precision@{KP} (ұсыныстың қанша үлесі оқырманның жасырын сүйікті жанр тобына түседі)",
          f"Оқырман саны: {len(prec['char'])}", "| Әдіс | Precision@10 |", "|---|---|"]
for name in ("char", "word", "char_no_genre", "word_no_genre", "popularity", "random"):
    lines.append(f"| {name} | {np.mean(prec[name]):.3f} |")
lines += ["", "(Hit@5 жоғарыдағы кестеде: жасырылған БІР кітапты табу, 272 кітапта өте қатал метрика.)"]

# кітаптарды кластерлеу
km_rows = []
for name in ("char", "word", "char_no_genre"):
    X = models[name].X
    km = KMeans(n_clusters=books.genre_group.nunique(), n_init=10, random_state=0).fit(X)
    sil = silhouette_score(X, km.labels_)
    ari = adjusted_rand_score(books.genre_group, km.labels_)
    km_rows.append((name, sil, ari))
    if name == "char":
        books["cluster"] = km.labels_
lines += ["", "## Кітаптарды кластерлеу (KMeans, k=жанр топтарының саны)", "| TF-IDF | silhouette | ARI (жанрмен) |", "|---|---|---|"]
for name, s, a in km_rows:
    lines.append(f"| {name} | {s:.3f} | {a:.3f} |")
lines += ["", "### Кластер құрамы (char)"]
for c, g in books.groupby("cluster"):
    genres = {k: int(v) for k, v in g.genre_group.value_counts().items()}
    lines.append(f"- кластер {c}: {len(g)} кітап, жанр топтары: {genres}")

# тексерудің үш мысалы және қате талдауы
by_id = books.set_index("book_id")
ex = ["", "## Тексерудің үш мысалы"]
shown = 0
for rid, test, train, top in log:
    if shown >= 3:
        break
    if test in top and len(train) >= 3:
        ex.append(f"- №{rid} оқырман ұнатады: " + ", ".join(by_id.loc[train, "title"]) +
                  f". Жасырылған «{by_id.loc[test, 'title']}» → топ-5: " +
                  ", ".join(by_id.loc[top, "title"]) + " ✔")
        shown += 1
miss = [(r, t, tr, tp) for r, t, tr, tp in log if t not in tp]
ex += ["", "## Қате мысалы"]
if miss:
    r, t, tr, tp = miss[0]
    ex.append(f"- №{r} оқырман: жасырылған «{by_id.loc[t, 'title']}» (жанр тобы {by_id.loc[t, 'genre_group']}), "
              f"ұнағандары ({', '.join(by_id.loc[tr, 'title'])}) бойынша ұсынылғаны: " +
              ", ".join(f"{by_id.loc[b, 'title']} [{by_id.loc[b, 'genre_group']}]" for b in tp))
ex.append(f"- Барлығы қателік: {len(miss)} / {len(log)}")
lines += ex

with open("results/results.md", "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
print("\n".join(lines))
