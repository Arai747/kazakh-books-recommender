"""СИНТЕТИКАЛЫҚ оқырман профильдерін жасау.

Барлық оқырмандар ОЙДАН ШЫҒАРЫЛҒАН. Нақты адамдар мен жеке деректер жоқ.
Нәтиже: data/synthetic_ratings.csv (reader_id, book_id, rating 1-5).

Қалай жасалады:
  * әр оқырманның 1-2 «сүйікті» жанр тобы (genre_group) бар (жасырын, файлға жазылмайды);
  * оқырман 30 кездейсоқ кітапты бағалайды;
  * сүйікті жанр кітабы 4-5, қалғандары 1-3 алады;
  * 15 % жағдайда баға «бұзылады» (шу: талғам мінсіз емес).
Іске қосу: python generate_readers.py
"""
import numpy as np
import pandas as pd

SEED = 42
N_READERS = 80
N_RATED = 30
NOISE = 0.15


def main():
    rng = np.random.default_rng(SEED)
    books = pd.read_csv("data/books.csv")
    genres = sorted(books.genre_group.unique())
    rows = []
    truth = []
    for rid in range(1, N_READERS + 1):
        n_fav = rng.choice([1, 2], p=[0.6, 0.4])
        fav = set(rng.choice(genres, size=n_fav, replace=False))
        truth.append((rid, ";".join(sorted(fav))))
        picked = rng.choice(books.book_id.values, size=N_RATED, replace=False)
        for bid in picked:
            g = books.loc[books.book_id == bid, "genre_group"].iloc[0]
            liked = g in fav
            if rng.random() < NOISE:
                liked = not liked
            rating = int(rng.integers(4, 6)) if liked else int(rng.integers(1, 4))
            rows.append((rid, int(bid), rating))
    out = pd.DataFrame(rows, columns=["reader_id", "book_id", "rating"])
    out.to_csv("data/synthetic_ratings.csv", index=False)
    # скрытая «ақиқат»: тек синтетикалық бағалауға арналған, нақты оқырманда мұндай дерек болмайды
    pd.DataFrame(truth, columns=["reader_id", "favorite_groups"]).to_csv("data/synthetic_readers_truth.csv", index=False)
    print(f"{out.reader_id.nunique()} синтетикалық оқырманнан {len(out)} баға сақталды")


if __name__ == "__main__":
    main()
